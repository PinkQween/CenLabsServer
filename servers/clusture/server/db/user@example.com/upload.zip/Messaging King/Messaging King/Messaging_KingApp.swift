//
//  Messaging_KingApp.swift
//  Messaging King
//
//  Created by Hanna Skairipa on 10/20/23.
//

import SwiftUI

@main
struct Messaging_KingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
